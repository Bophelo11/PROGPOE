public class msgs {
    import java.util.Random;

    public class Message {

        // Properties tracking a single message entity
        private String messageID;
        private String recipientCell;
        private String messageContent;
        private int currentMessageIndex;
        private String messageHash;
        private String actionFlag; // "Sent", "Stored", "Disregard"

        // Constructor
        public Message(int currentMessageIndex, String recipientCell, String messageContent) {
            this.currentMessageIndex = currentMessageIndex;
            this.recipientCell = recipientCell;
            this.messageContent = messageContent;
            this.messageID = generateRandomID();
            this.messageHash = createMessageHash();
        }

        // Default constructor for utility method access
        public Message() {}

        // Generates a random 10-digit number as a String
        private String generateRandomID() {
            Random rand = new Random();
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < 10; i++) {
                sb.append(rand.nextInt(10));
            }
            return sb.toString();
        }

        // Method Functionality: Ensures message ID is not more than 10 characters
        public boolean checkMessageID(String id) {
            return id != null && id.length() <= 10;
        }

        // Method Functionality: Check cell format using the rule from Part 1
        public String checkRecipientCell(String cellNumber) {
            if (cellNumber != null && cellNumber.startsWith("+27") && cellNumber.length() == 12) {
                return "Cell phone number successfully captured.";
            } else {
                return "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
            }
        }

        // Method Functionality: Creates and returns the formatted uppercase Message Hash
        public String createMessageHash() {
            if (messageContent == null || messageContent.trim().isEmpty()) {
                return "00:0:EMPTY";
            }

            // 1. Get first two digits of Message ID
            String idPrefix = (messageID != null && messageID.length() >= 2) ? messageID.substring(0, 2) : "00";

            // 2. Extract first and last words, cleaning out basic punctuation variations
            String cleanedContent = messageContent.trim().replaceAll("[\\?\\!\\,\\.]", "");
            String[] words = cleanedContent.split("\\s+");

            String firstWord = words[0];
            String lastWord = words[words.length - 1];

            // 3. Assemble and capitalize
            String hash = idPrefix + ":" + currentMessageIndex + ":" + firstWord + lastWord;
            return hash.toUpperCase();
        }

        // Method Functionality: Simulates user action choice options
        public String sentMessage(int choice) {
            switch (choice) {
                case 1:
                    this.actionFlag = "Sent";
                    return "Message successfully sent.";
                case 0:
                    this.actionFlag = "Disregard";
                    return "Press 0 to delete the message.";
                case 3:
                    this.actionFlag = "Stored";
                    storeMessage();
                    return "Message successfully stored.";
                default:
                    return "Invalid choice.";
            }
        }

        // Research Task: Simulates writing out to a flat JSON file format structure
        public void storeMessage() {
            String jsonStructure = "{\n" +
                    "  \"messageID\": \"" + messageID + "\",\n" +
                    "  \"recipient\": \"" + recipientCell + "\",\n" +
                    "  \"hash\": \"" + messageHash + "\",\n" +
                    "  \"content\": \"" + messageContent + "\"\n" +
                    "}";
            // In real execution, you would use a FileWriter here to output to a .json file.
            System.out.println("--> Saved to JSON backend cleanly:\n" + jsonStructure);
        }

        // Getters for Array processing operations
        public String getMessageID() { return messageID; }
        public String getRecipientCell() { return recipientCell; }
        public String getMessageContent() { return messageContent; }
        public String getMessageHash() { return messageHash; }
        public String getActionFlag() { return actionFlag; }
    }
}

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.org.junit.jupiter.api.Assertions.*;

public class Testing {
    @Test
    public void testCheckUserName_Correct() {
        Login login = new Login();
        // Test Data: "kyl_1" -> Expects true
        assertTrue(login.checkUserName("kyl_1"));
    }

    @Test
    public void testCheckUserName_Incorrect() {
        Login login = new Login();
        // Test Data: "kyle!!!!!!" -> Expects false
        assertFalse(login.checkUserName("kyle!!!!!!"));
    }

    @Test
    public void testCheckPasswordComplexity_Success() {
        Login login = new Login();
        // Test Data: "Ch&&sec@ke99!" -> Expects true
        assertTrue(login.checkPasswordComplexity("Ch&&sec@ke99!"));
    }

    @Test
    public void testCheckPasswordComplexity_Failed() {
        Login login = new Login();
        // Test Data: "password" -> Expects false
        assertFalse(login.checkPasswordComplexity("password"));
    }

    @Test
    public void testCheckCellPhoneNumber_Correct() {
        Login login = new Login();
        // Test Data: "+27838968976" -> Expects true
        assertTrue(login.checkCellPhoneNumber("+27838968976"));
    }

    @Test
    public void testCheckCellPhoneNumber_Incorrect() {
        Login login = new Login();
        // Test Data: "08966553" -> Expects false
        assertFalse(login.checkCellPhoneNumber("08966553"));
    }

    @Test
    public void testLogin_Successful() {
        Login login = new Login();
        // Registering first to set the credentials
        login.registerUser("kyl_1", "Ch&&sec@ke99!", "+27838968976", "Kyle", "Janse");

        boolean loginResult = login.loginUser("kyl_1", "Ch&&sec@ke99!");
        assertTrue(loginResult);

        String expectedMessage = "Welcome Kyle, Janse it is great to see you again.";
        assertEquals(expectedMessage, login.returnLoginStatus(loginResult));
    }

    @Test
    public void testLogin_Failed() {
        Login login = new Login();
        login.registerUser("kyl_1", "Ch&&sec@ke99!", "+27838968976", "Kyle", "Janse");

        boolean loginResult = login.loginUser("kyl_1", "wrong_password");
        assertFalse(loginResult);

        String expectedMessage = "Username or password incorrect, please try again.";
        assertEquals(expectedMessage, login.returnLoginStatus(loginResult));
    }
}



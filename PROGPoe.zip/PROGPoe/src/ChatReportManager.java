import java.util.ArrayList;

public class ChatReportManager {
    import java.util.ArrayList;

    public class ChatReportManager {

        // Parallel dynamically sized tracking structures to store data safely
        private ArrayList<String> sentMessages = new ArrayList<>();
        private ArrayList<String> disregardedMessages = new ArrayList<>();
        private ArrayList<String> storedMessages = new ArrayList<>();
        private ArrayList<String> messageHashes = new ArrayList<>();
        private ArrayList<String> messageIDs = new ArrayList<>();
        private ArrayList<String> recipients = new ArrayList<>();

        // Adds a fully verified message stack element to our active parallel tracking rows
        public void addMessageRecord(Message msg) {
            messageIDs.add(msg.getMessageID());
            messageHashes.add(msg.getMessageHash());
            recipients.add(msg.getRecipientCell());

            String status = msg.getActionFlag();
            if ("Sent".equals(status)) {
                sentMessages.add(msg.getMessageContent());
            } else if ("Disregard".equals(status)) {
                disregardedMessages.add(msg.getMessageContent());
            } else if ("Stored".equals(status)) {
                storedMessages.add(msg.getMessageContent());
            }
        }

        // Feature A: Display sender and recipient details of all active stored records
        public void displayStoredSendersAndRecipients() {
            System.out.println("--- Stored Message Recipients ---");
            for (int i = 0; i < messageIDs.size(); i++) {
                System.out.println("ID: " + messageIDs.get(i) + " | Recipient: " + recipients.get(i));
            }
        }

        // Feature B: Find and display the longest string message content in memory
        public String displayLongestMessage() {
            String longest = "";
            // Scanning combined array categories or focusing directly on total inputs
            for (String msg : sentMessages) {
                if (msg.length() > longest.length()) longest = msg;
            }
            for (String msg : storedMessages) {
                if (msg.length() > longest.length()) longest = msg;
            }
            return longest;
        }

        // Feature C: Search for a message ID and return matching values
        public String searchByMessageID(String id) {
            for (int i = 0; i < messageIDs.size(); i++) {
                if (messageIDs.get(i).equals(id)) {
                    return "Recipient: " + recipients.get(i) + "\nMessage: " + sentMessages.get(i);
                }
            }
            return "Message ID not found.";
        }

        // Feature D: Find all entries matching a single specific target cell recipient
        public void searchAllByRecipient(String recipientCell) {
            boolean found = false;
            for (int i = 0; i < recipients.size(); i++) {
                if (recipients.get(i).equals(recipientCell)) {
                    System.out.println("Found -> Hash: " + messageHashes.get(i) + " | Msg: " + sentMessages.get(i));
                    found = true;
                }
            }
            if (!found) System.out.println("No records found matching recipient " + recipientCell);
        }

        // Feature E: Delete a unique system message row safely via target Hash search matching
        public String deleteMessageByHash(String hash) {
            for (int i = 0; i < messageHashes.size(); i++) {
                if (messageHashes.get(i).equals(hash)) {
                    String deletedText = sentMessages.get(i);
                    messageIDs.remove(i);
                    messageHashes.remove(i);
                    recipients.remove(i);
                    sentMessages.remove(i); // Assuming sync alignments across indexing structures
                    return "Message: \"" + deletedText + "\" successfully deleted.";
                }
            }
            return "Hash code match not located.";
        }

        // Feature F: Structural system complete details report listing printouts
        public String printMessagesReport() {
            StringBuilder report = new StringBuilder("=== FULL STATUS REPORT ===\n");
            for (int i = 0; i < messageHashes.size(); i++) {
                report.append("Hash: ").append(messageHashes.get(i))
                        .append(" | Recipient: ").append(recipients.get(i))
                        .append("\n");
            }
            return report.toString();
        }

        public int returnTotalMessages() {
            return messageIDs.size();
        }
    }
}

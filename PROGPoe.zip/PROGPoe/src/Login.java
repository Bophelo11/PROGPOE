import java.util.regex.Pattern;

class Login {
    // Instance variables to hold registered user data
    private String registeredUsername;
    private String registeredPassword;
    private String registeredFirstName = "Kyle"; // Defaulting or capturing via registration
    private String registeredLastName = "Janse";  // Defaulting or capturing via registration
    private String registeredCellNumber;

    // 1. Check Username
    public boolean checkUserName(String username) {
        // Must contain an underscore (_) and be <= 5 characters long
        return username.contains("_") && username.length() <= 5;
    }

    // 2. Check Password Complexity
    public boolean checkPasswordComplexity(String password) {
        // At least 8 chars, 1 uppercase, 1 number, 1 special character
        String regex = "^(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*()_+\\-=\\[\\]{};':\",.<>/?]).{8,}$";
        return Pattern.matches(regex, password);
    }

    // 3. Check South African Cell Phone Number
    public boolean checkCellPhoneNumber(String cellNumber) {
        // Must include international country code (+27) and be exactly 11 characters total (+27 + 9 digits)
        // Example test data provided: +27838968976
        String regex = "^\\+27[0-9]{9}$";
        return Pattern.matches(regex, cellNumber);
    }

    // 4. Register User Method
    public String registerUser(String username, String password, String cellNumber, String firstName, String lastName) {
        if (!checkUserName(username)) {
            return "Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.";
        }
        if (!checkPasswordComplexity(password)) {
            return "Password is not correctly formatted; please ensure the password contains at least eight characters, a capital letter, a number, and a special character.";
        }
        if (!checkCellPhoneNumber(cellNumber)) {
            return "Cell phone number incorrectly formatted or does not contain international code.";
        }

        // If all conditions pass, save the data and return success
        this.registeredUsername = username;
        this.registeredPassword = password;
        this.registeredCellNumber = cellNumber;
        this.registeredFirstName = firstName;
        this.registeredLastName = lastName;

        return "Username successfully captured.\nPassword successfully captured.\nCell phone number successfully added.";
    }

    // 5. Login Verification
    public boolean loginUser(String username, String password) {
        if (this.registeredUsername == null || this.registeredPassword == null) {
            return false;
        }
        return this.registeredUsername.equals(username) && this.registeredPassword.equals(password);
    }

    // 6. Return Login Status Message
    public String returnLoginStatus(boolean loginSuccess) {
        if (loginSuccess) {
            return "Welcome " + registeredFirstName + ", " + registeredLastName + " it is great to see you again.";
        } else {
            return "Username or password incorrect, please try again.";
        }
    }
}